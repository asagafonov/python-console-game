#!/usr/bin/env python3
from brain_games import even_game


def main():
    even_game.brain_even()
