#!/usr/bin/env python3
from brain_games import calc_game


def main():
    calc_game.brain_calc()
