from random import randint
import prompt

def is_even(n):
    return True if n % 2 == 0 else False

def brain_even(rounds=3):
    print('Answer "yes" if the number is even, otherwise answer "no".')
    for round in range(rounds):
        num = randint(1, 100)
        print('Question: {}'.format(str(num)))
        user_answer = prompt.string('Your answer: ')
        is_correct = (user_answer == 'yes' and is_even(num)) or (user_answer == "no" and not is_even(num))
        if is_correct:
            print('Correct!')
        else:
            print('Let\'s try again')
            return
    print('Congratulations! You win!')
