from random import randint
import prompt

operations = ['+', '-', '*']

def is_even(n):
    return True if n % 2 == 0 else False

def brain_calc(rounds=3):
    print('What is the result of the expression?')
    for round in range(rounds):
        num1 = randint(1, 100)
        num2 = randint(1, 100)
        random_operation_index = randint(0, 2)
        print('Question: {} {} {}'.format(str(num1), operations[random_operation_index], str(num2)))
        user_answer = prompt.string('Your answer: ')
        is_correct = False
        if operations[random_operation_index] == '+':
            is_correct = True if num1 + num2 == int(user_answer) else False
        elif operations[random_operation_index] == '-':
            is_correct = True if num1 - num2 == int(user_answer) else False
        elif operations[random_operation_index] == '*':
            is_correct = True if num1 * num2 == int(user_answer) else False

        if is_correct:
            print('Correct!')
        else:
            print('Let\'s try again')
            return
    print('Congratulations! You win!')
